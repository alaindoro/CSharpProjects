﻿namespace secondTask
{
    class Program
    {
        static void Main(string[] args)

            // Тут баг: если неправильно ввести значение карты, то она останется неучтенной.Пробовала всякое, но не додумалась.
            // Может можно как-то не инициируя новый виток цикла for через default перезапустить switch?
        {
            Console.WriteLine("Привет, игрок. Сколько у тебя карт?");
            int i = int.Parse(Console.ReadLine());
            int sum = 0;
            int n = 0;
            for (; i != 0; i--)
            {
                n++;
                Console.WriteLine($"Введи значение {n} карты. J - валет, Q - дама, K - король, T - туз.");
                string card = (Console.ReadLine());
                switch (card)
                {
                    case "1":
                        sum = sum + 1;
                        break;
                    case "2":
                        sum = sum + 2;
                        break;
                    case "3":
                        sum = sum + 3;
                        break;
                    case "4":
                        sum = sum + 4;
                        break;
                    case "5":
                        sum = sum + 5;
                        break;
                    case "6":
                        sum = sum + 6;
                        break;
                    case "7":
                        sum = sum + 7;
                        break;
                    case "8":
                        sum = sum + 8;
                        break;
                    case "9":
                        sum = sum + 9;
                        break;
                    case "10":
                    case "J":
                    case "j":
                    case "q":
                    case "Q":
                    case "k":
                    case "K":
                    case "t":
                    case "T":
                        sum = sum + 10;
                        break;
                    default:
                        Console.WriteLine("Я не знаю такой карты, Друг. J - валет, Q - дама, K - король, T - туз.");
                        break;
                }
            }
            Console.WriteLine($"Поздравляю, ты набрал {sum} очков.");
        }

    }
}
