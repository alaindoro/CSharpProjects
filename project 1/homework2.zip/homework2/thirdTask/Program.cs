﻿namespace thirdTask
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число");
            int number = int.Parse(Console.ReadLine());
            bool isNumberSimple = true;
            int i = 2;
            while (number>i)
            {
                if (number % i == 0)
                {
                    Console.WriteLine("Это число не является простым");
                    isNumberSimple = false;
                    break;
                }
                else
                {
                    Console.WriteLine("Это число простое");
                    break;
                }
            }
        }
    }
}